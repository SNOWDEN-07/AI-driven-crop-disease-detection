# Script for inference on new images
