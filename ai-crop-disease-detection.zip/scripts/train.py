# Script to train CNN on crop disease dataset
