# Image enhancement, resizing, normalization etc.
