# CNN architecture for disease classification
