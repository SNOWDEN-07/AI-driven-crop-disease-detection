# Functions to load and augment image datasets
